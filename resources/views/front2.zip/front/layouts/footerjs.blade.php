<!-- Jquery Slim JS -->
<script src="{{asset('front/assets/js/jquery.min.js')}}"></script>
<!-- Bootstrap JS -->
<script src="{{asset('front/assets/js/bootstrap.bundle.min.js')}}"></script>
<!-- Meanmenu JS -->
<script src="{{asset('front/assets/js/jquery.meanmenu.js')}}"></script>
<!-- Appear Min JS -->
<script src="{{asset('front/assets/js/jquery.appear.min.js')}}"></script>
<!-- Odometer Min JS -->
<script src="{{asset('front/assets/js/odometer.min.js')}}"></script>
<!-- Owl Carousel JS -->
<script src="{{asset('front/assets/js/owl.carousel.min.js')}}"></script>
<!-- Popup JS -->
<script src="{{asset('front/assets/js/jquery.magnific-popup.min.js')}}"></script>
<!-- Nice Select JS -->
<script src="{{asset('front/assets/js/jquery.nice-select.min.js')}}"></script>
<!-- Ajaxchimp JS -->
<script src="{{asset('front/assets/js/jquery.ajaxchimp.min.js')}}"></script>
<!-- Form Validator JS -->
<script src="{{asset('front/assets/js/form-validator.min.js')}}"></script>
<!-- Contact JS -->
<script src="{{asset('front/assets/js/contact-form-script.js')}}"></script>
<!-- Wow JS -->
<script src="{{asset('front/assets/js/wow.min.js')}}"></script>
<!-- Custom JS -->
<script src="{{asset('front/assets/js/main.js')}}"></script>
<script src="https://kit.fontawesome.com/8c73d8862b.js" crossorigin="anonymous">
    
</script>






  <!--Start of REVE Chat Script-->
 <script type='text/javascript'>
 window.$_REVECHAT_API || (function(d, w) { var r = $_REVECHAT_API = function(c) {r._.push(c);}; w.__revechat_account='10685105';w.__revechat_version=2;
   r._= []; var rc = d.createElement('script'); rc.type = 'text/javascript'; rc.async = true; rc.setAttribute('charset', 'utf-8');
   rc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'static.revechat.com/widget/scripts/new-livechat.js?'+new Date().getTime();
   var s = d.getElementsByTagName('script')[0]; s.parentNode.insertBefore(rc, s);
 })(document, window);
</script>
 <!--End of REVE Chat Script -->
@yield('js')
