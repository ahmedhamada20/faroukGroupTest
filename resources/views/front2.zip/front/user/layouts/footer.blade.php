<footer class="footer">
    <a href="{{route('home')}}" target=")_blank">Farouk Group</a>  © {{date('Y')}} | {{date('Y')+1}}
</footer>
