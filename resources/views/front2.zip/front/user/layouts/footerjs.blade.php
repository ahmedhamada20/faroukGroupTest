<!-- jQuery  -->
<script src="{{asset('front/user/assets/js/jquery.min.js')}}"></script>
<script src="{{asset('front/user/assets/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('front/user/assets/js/modernizr.min.js')}}"></script>
<script src="{{asset('front/user/assets/js/detect.js')}}"></script>
<script src="{{asset('front/user/assets/js/fastclick.js')}}"></script>
<script src="{{asset('front/user/assets/js/jquery.slimscroll.js')}}"></script>
<script src="{{asset('front/user/assets/js/jquery.blockUI.js')}}"></script>
<script src="{{asset('front/user/assets/js/waves.js')}}"></script>
<script src="{{asset('front/user/assets/js/jquery.nicescroll.js')}}"></script>
<script src="{{asset('front/user/assets/js/jquery.scrollTo.min.js')}}"></script>

<!--Morris Chart-->
<script src="{{asset('front/user/plugins/morris/morris.min.js')}}"></script>
<script src="{{asset('front/user/plugins/raphael/raphael.min.js')}}"></script>

<!-- dashboard js -->
<script src="{{asset('front/user/assets/pages/dashboard.int.js')}}"></script>

<!-- App js -->
<script src="{{asset('front/user/assets/js/app.js')}}"></script>
<!-- Required datatable js -->
<script src="{{asset('front/user/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('front/user/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{asset('front/user/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('front/user/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{asset('front/user/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{asset('front/user/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{asset('front/user/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{asset('front/user/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{asset('front/user/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{asset('front/user/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{asset('front/user/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('front/user/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>
<script src="{{asset('front/user/assets/pages/datatables.init.js')}}"></script>
@yield('js')
