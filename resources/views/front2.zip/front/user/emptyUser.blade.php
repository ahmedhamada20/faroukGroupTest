@extends('front.user.master')

@section('title')
@endsection

@section('css')
@endsection

@section('content')
@endsection

@section('js')
@endsection
